#include "_Timer.h"

_Timer::_Timer()
{
    //ctor
    startTime = clock();
}

_Timer::~_Timer()
{
    //dtor
}
