#ifndef _COMMON_H
#define _COMMON_H


#include <string.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <iostream>
#include <windows.h>	// Header File For Windows
#include <gl/gl.h>
#include <time.h>
#include <cmath>
#include <cstdlib> // for rand() and srand()
#include <ctime> // for time()

#define PI 3.1415926

typedef struct {
    float x;
    float y;
}vec2;

typedef struct {
    float x;
    float y;
    float z;
}vec3;

typedef struct {
    float r;
    float g;
    float b;
}col3;

typedef struct {
    float x;
    float y;
    float z;
    float w;
}vec4;


using namespace std;

#endif // _COMMON_H
