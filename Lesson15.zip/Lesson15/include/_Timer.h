#ifndef _TIMER_H
#define _TIMER_H

#include <_Common.h>


class _Timer
{
    public:
        _Timer();
        virtual ~_Timer();

        clock_t startTime;

    protected:

    private:
};

#endif // _TIMER_H
