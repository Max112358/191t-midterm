#ifndef _PARTICLES_H
#define _PARTICLES_H


#include <_Common.h>
#include <_TextureLoader.h>
#include <_Timer.h>

#define MAX_DROPS 50000
class _Particles
{
    public:
        _Particles();
        virtual ~_Particles();

        int numDrops;
        int newDrops;


        typedef struct
        {
            bool live;
            vec3 pos;
            vec3 dir;
            col3 color;
            vec3 velocity;
            float alpha;
            float t = 0;

            float mass;
            float radius;

            float expRadius;
            float angle;
        }particle;

        float xMax = 1.0;
        float xMin = 0.0;
        float yMax = 1.0;
        float yMin = 0.0;

        void drawParticles();
        void updateParticles();
        void generateParticles(float,float);
        void buildQuad(float,float,float,float);
        void initParticles(int,int,int,char*);

        _TextureLoader *myTex = new _TextureLoader();
        _Timer *myTime = new _Timer();
        particle drops[MAX_DROPS];

    protected:

    private:
};

#endif // _PARTICLES_H
